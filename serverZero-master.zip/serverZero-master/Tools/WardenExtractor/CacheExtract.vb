﻿Imports System.IO

Public Module Module_CacheExtract

    Public Sub ExtractCache()
        Console.Write("Name of WDB: ")
        Dim sWDB As String = Console.ReadLine

        If File.Exists(sWDB) = False Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("The file [{0}] did not exist.", sWDB)
            Exit Sub
        End If
        Dim fs As New FileStream(sWDB, FileMode.Open, FileAccess.Read, FileShare.Read)
        Dim br As New BinaryReader(fs)

        Dim Header As String = br.ReadChars(4)
        Dim Version As UInteger = br.ReadUInt32()
        Dim Lang As String = Reverse(br.ReadChars(4))
        Dim Unk As Byte() = br.ReadBytes(8)

        Console.ForegroundColor = ConsoleColor.White

        Directory.CreateDirectory("Modules")
        Do While (fs.Position + 20) <= fs.Length
            Dim ModName As String = ToHex(br.ReadBytes(16))
            Dim DataLen As Integer = br.ReadInt32()
            If DataLen = 0 Then Continue Do
            Dim ModLen As Integer = br.ReadInt32()

            Dim ModData(ModLen - 1) As Byte
            br.Read(ModData, 0, ModLen)

            Dim fs2 As New FileStream("Modules\" & ModName & ".mod", FileMode.Create, FileAccess.Write, FileShare.None)
            fs2.Write(ModData, 0, ModLen)
            fs2.Close()
            fs2.Dispose()
            fs2 = Nothing

            Console.WriteLine("Module: {0} [{1} bytes]", ModName, ModLen)
        Loop

        fs.Close()
        fs.Dispose()
        fs = Nothing
        br = Nothing
    End Sub

    Public Sub ConvertWDB()
        Console.Write("Name of WDB: ")
        Dim sWDB As String = Console.ReadLine

        If File.Exists(sWDB) = False Then
            Console.ForegroundColor = ConsoleColor.Red
            Console.WriteLine("The file [{0}] did not exist.", sWDB)
            Exit Sub
        End If
        Dim fs As New FileStream(sWDB, FileMode.Open, FileAccess.Read, FileShare.Read)
        Dim br As New BinaryReader(fs)

        Dim ms As New MemoryStream
        Dim bw As New BinaryWriter(ms)

        Dim Header As String = br.ReadChars(4)
        Dim Version As UInteger = br.ReadUInt32()
        Dim Lang As String = Reverse(br.ReadChars(4))
        Dim Unk1 As Integer = br.ReadInt32()
        Dim Unk2 As Integer = br.ReadInt32()

        bw.Write(CByte(Asc(Header(0))))
        bw.Write(CByte(Asc(Header(1))))
        bw.Write(CByte(Asc(Header(2))))
        bw.Write(CByte(Asc(Header(3))))
        bw.Write(Version)
        bw.Write(CByte(Asc(Lang(3))))
        bw.Write(CByte(Asc(Lang(2))))
        bw.Write(CByte(Asc(Lang(1))))
        bw.Write(CByte(Asc(Lang(0))))
        bw.Write(Unk1)
        bw.Write(Unk2)
        Console.WriteLine("Unk1: {0}{1}Unk2: {2}", Unk1, vbNewLine, Unk2)

        Console.ForegroundColor = ConsoleColor.White
        bw.Write(1I) 'Count of modules?
        Do While (fs.Position + 20) <= fs.Length
            Dim byteName() As Byte = br.ReadBytes(16)
            Dim ModName As String = ToHex(byteName)
            Dim DataLen As Integer = br.ReadInt32()

            bw.Write(byteName, 0, byteName.Length)
            bw.Write(DataLen)

            If DataLen = 0 Then
                Continue Do
            End If
            Dim ModLen As Integer = br.ReadInt32()

            bw.Write(ModLen)

            Dim ModData(ModLen - 1) As Byte
            br.Read(ModData, 0, ModLen)
            bw.Write(ModData, 0, ModLen)

            Console.WriteLine("Module: {0} [{1} bytes]", ModName, ModLen)
        Loop
        fs.Close()
        fs.Dispose()
        fs = Nothing
        br = Nothing

        Dim fs2 As New FileStream(sWDB.Replace(Path.GetExtension(sWDB), "") & ".new.wdb", FileMode.Create, FileAccess.Write, FileShare.Read)
        Dim newFile() As Byte = ms.ToArray
        fs2.Write(newFile, 0, newFile.Length)
        newFile = Nothing
        fs2.Close()
        fs2.Dispose()
        fs2 = Nothing

        ms.Close()
        ms.Dispose()
        ms = Nothing
        bw = Nothing
    End Sub

End Module
